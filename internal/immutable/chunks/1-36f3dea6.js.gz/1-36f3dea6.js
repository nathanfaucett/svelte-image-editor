import{default as t}from"../components/error.svelte-e5635b4a.js";export{t as component};
