import{default as t}from"../components/pages/_page.svelte-e06efb62.js";export{t as component};
